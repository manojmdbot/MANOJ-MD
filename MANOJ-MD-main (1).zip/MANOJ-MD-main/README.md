***
</p> <p align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Rubik+Dirt&size=65&pause=1000&color=F72C3F&background=FF20A500&center=true&vCenter=true&width=1000&height=150&lines=MANOJ-MD;MADE+BY+MANOJ+TECH" alt="Typing SVG" /></a>

***

<p align = center>   <img src="https://files.catbox.moe/de82e3.jpg"</p>
<p align="center">

  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fmanojmdbot%2FMANOJ-MD&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/manojmdbot/MANOJ-MD/fork">
    <img src="https://img.shields.io/github/forks/manojmdbot/MANOJ-MD?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/manojmdbot/MANOJ-MD/stargazers">
    <img src="https://img.shields.io/github/stars/manojmdbot/MANOJ-MD?style=social">
  </a>
</p>

<p align="center">
  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://img.shields.io/github/repo-size/manojmdbot/MANOJ-MD?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://img.shields.io/github/license/manojmdbot/MANOJ-MD?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://img.shields.io/github/languages/top/manojmdbot/MANOJ-MD?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://img.shields.io/static/v1?label=Author&message=MANOJ%20Tech&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://github.com/manojmdbot/MANOJ-MD">
    <img src="https://img.shields.io/badge/OUR%20%20%20TEAM-DARK%20DHACKER%20ZONE%20-purple&style=plastic">

  </a>
</p>
 
***


<h2 align="center">𝗖𝗢𝗡𝗡𝗘𝗖𝗧 𝗧𝗢 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣</h2>

<p align="center">
<a href='https://github.com/manojmdbot/MANOJ-MD/fork' target="_blank"><img alt='Fork Repo' src='https://img.shields.io/badge/-Fork Repo-grey?style=for-the-badge&logo=github&logoColor=white'/< width=115 height=28/p></a>

<p align="center">
<a href='https://MANOJ-md-main-web.vercel.app/' target="_blank"><img alt='Pair Code' src='https://img.shields.io/badge/-Pair Code-darkgreen?style=for-the-badge&logo=Whatsapp&logoColor=white'/< width=115 height=28/p></a>

<p align="center"> 𝗨𝗣𝗗𝗔𝗧𝗘 𝗬𝗢𝗨𝗥 𝗖𝗢𝗡𝗙𝗜𝗚.𝗝𝗦 - 𝗔𝗗𝗗 𝗦𝗘𝗦𝗦𝗜𝗢𝗡-𝗜𝗗 𝗢𝗥 𝗦𝗲𝘀𝘀𝗶𝗼𝗻 - 𝗔𝗗𝗗 𝗖𝗿𝗲𝗱𝘀.𝗷𝘀𝗼𝗻</p>

***


<h2 align="center">𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</h2>

<p align="center">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-blue?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-heroku ‎ deploy-blue?style=for-the-badge&logo=heroku&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-blue?style=for-the-badge&logo=render&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://app.koyeb.com/services/new?service_type=web&step=review&type=git&repository=github.com%2Fmanojmdbot%2FMANOJ-MD&instance_type=free&regions=fra&env[SESSION_ID]=your_default_session_id&env[MONGODB]=your_default_mongodb_url&env[PREFIX]=.&env[mode]=public&env[OWNER_NUMBER]=94702481115&env[ALIVE_IMG]=your_default_alive_image_url&env[ALIVE_MSG]=I%20am%20alive!&env[AUTO_VOICE]=false&env[ANTI_BAD_WORDS_ENABLED]=true&env[AUTO_READ_STATUS]=true&env[ANTI_BAD_WORDS]=pakayo,huththo&env[ANTI_LINK]=false&env[ALWAYS_ONLINE]=false&env[ALWAYS_TYPING]=false&env[ALWAYS_RECORDING]=false&env[ANTI_BOT]=true&env[ANTI_DELETE]=true&env[packname]=🪄MANOJ&env[author]=MANOJ%20x%20MANOJ&env[OPENWEATHER_API_KEY]=2d61a72574c11c4f36173b627f8cb177&env[ELEVENLABS_API_KEY]=sk_6438bcc100d96458f8de0602aec662f4ba14b905fd090ad3&env[SHODAN_API]=cbCkidr6qd7AFVaYs56MuCouGfM8gFki&env[PEXELS_API_KEY]=39WCzaHAX939xiH22NCddGGvzp7cgbu1VVjeYUaZXyHUaWlL1LFcVFxH&env[OMDB_API_KEY]=76cb7f39&env[PIXABAY_API_KEY]=23378594-7bd620160396da6e8d2ed4d53&env[ZIPCODEBASE_API_KEY]=0f94a5f0-6ea4-11ef-81da-579be4fb031c&env[GOOGLE_API_KEY]=AIzaSyD93IeJsouK51zjKgyHAwBIAlqr-a8mnME&env[GOOGLE_CX]=AIzaSyD93IeJsouK51zjKgyHAwBIAlqr-a8mnME&env[PASTEBIN_API_KEY]=uh8QvO6vQJGtIug9WvjdTAPx_ZAFJAxn&dockerfile=./Dockerfile
' target="_blank"><img alt='Koyeb' src='https://img.shields.io/badge/-koyeb deploy-blue?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>

<p align="center">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-blue?style=for-the-badge&logo=netlify&logoColor=white'/< width=150 height=28/p></a> <h6>

<p align="center">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-blue?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> <h6>

<p align="center">
  <a href='https://github.com/manojmdbot/MANOJ-MD/blob/main/WORKFLOW.md' target="_blank">
    <img alt='Workflow' src='https://img.shields.io/badge/-WorkFlow%20Deploy-blue?style=for-the-badge&logo=github&logoColor=white' width="150" height="28"/>
  </a>



 


***

<h2 align="center">𝗥𝗘𝗠𝗜𝗡𝗗𝗘𝗥</h2>
<p style="text-align: center; font-size: 1.2em;">
  <strong>Important:</strong> This bot is not affiliated with <em>WhatsApp Inc.</em> 
  Misusing this bot may result in a <strong>ban</strong> on your WhatsApp account. 
  Please note that accounts can only be unbanned once.
</p>
<p style="text-align: center; font-size: 1.2em;">
  I am not responsible for any actions leading to the banning of your account. 
  Use at your own risk, keeping this warning in mind.
</p>

***
<h2 align="center">𝗡𝗢𝗧𝗜𝗖𝗘</h2>
<p style="text-align: center; font-size: 1.2em;">
  <strong>Not For Sale</strong><br>
  - If any plugin's code is obfuscated, you do not have permission to edit it in any form.<br>
  - Please remember to give credit if you are using or re-uploading my plugins/files.<br>
  - Wishing you a wonderful day ahead! 
</p>
    
***

</div>


